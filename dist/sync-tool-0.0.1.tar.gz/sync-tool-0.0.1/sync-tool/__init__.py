from sync import getDataFromServer
from sync import downloadFile
from sync import handleOneDownload
from sync import downloadPage
from sync import initiateDownload
from sync import getAllPages
from sync import main